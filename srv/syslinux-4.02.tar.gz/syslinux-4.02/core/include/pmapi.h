#ifndef PMAPI_H
#define PMAPI_H

#include <syslinux/pmapi.h>

size_t pmapi_read_file(uint16_t *, void *, size_t);

#endif /* PMAPI_H */
