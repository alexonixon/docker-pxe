#ifndef _BITS_UMALLOC_H
#define _BITS_UMALLOC_H

/** @file
 *
 * i386-specific user memory allocation API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

#include <gpxe/memtop_umalloc.h>

#endif /* _BITS_UMALLOC_H */
