#ifndef _GPXE_LOGIN_UI_H
#define _GPXE_LOGIN_UI_H

/** @file
 *
 * Login UI
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

extern int login_ui ( void );

#endif /* _GPXE_LOGIN_UI_H */
