/*
 * Trivial C program to test the compiler
 */

int main(int argc, char *argv[])
{
    return 0;
}
