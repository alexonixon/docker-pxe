static int isspace(int c) {
  return (c == ' ');
}
