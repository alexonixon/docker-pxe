/* Must be included first of all */
#ifdef __ASSEMBLY__
	.code16
#else
__asm__ (".code16gcc");
#endif
